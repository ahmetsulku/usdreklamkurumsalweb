<?php
/**
 * Basit Router Sınıfı
 */

class Router
{
    private array $routes = [];
    private array $params = [];
    
    /**
     * GET route ekle
     */
    public function get(string $path, string $handler): self
    {
        $this->addRoute('GET', $path, $handler);
        return $this;
    }
    
    /**
     * POST route ekle
     */
    public function post(string $path, string $handler): self
    {
        $this->addRoute('POST', $path, $handler);
        return $this;
    }
    
    /**
     * Route ekle
     */
    private function addRoute(string $method, string $path, string $handler): void
    {
        // Path'i regex'e çevir
        $pattern = preg_replace('/\{([a-zA-Z_]+)\}/', '(?P<$1>[^/]+)', $path);
        $pattern = '#^' . $pattern . '$#';
        
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'pattern' => $pattern,
            'handler' => $handler
        ];
    }
    
    /**
     * Route'u çalıştır
     */
    public function dispatch(string $uri, string $method): bool
    {
        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) {
                continue;
            }
            
            if (preg_match($route['pattern'], $uri, $matches)) {
                // Named parametreleri al
                $this->params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
                
                // Handler'ı çalıştır
                return $this->callHandler($route['handler']);
            }
        }
        
        return false;
    }
    
    /**
     * Handler'ı çağır
     */
    private function callHandler(string $handler): bool
    {
        if (strpos($handler, '@') === false) {
            return false;
        }
        
        list($controllerName, $methodName) = explode('@', $handler);
        
        if (!class_exists($controllerName)) {
            return false;
        }
        
        $controller = new $controllerName();
        
        if (!method_exists($controller, $methodName)) {
            return false;
        }
        
        // Parametreleri metoda gönder
        call_user_func_array([$controller, $methodName], $this->params);
        
        return true;
    }
    
    /**
     * Parametreleri al
     */
    public function getParams(): array
    {
        return $this->params;
    }
    
    /**
     * Mevcut URI'yi al
     */
    public static function currentUri(): string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $uri = strtok($uri, '?');
        return rtrim($uri, '/') ?: '/';
    }
}
```

---

## Kurulum Özeti - Tüm Dosya Listesi

İşte oluşturmanız gereken tüm dosyaların listesi:
```
/
├── index.php                          ← Front Controller
├── .htaccess                          ← Apache ayarları
├── config/
│   └── config.php                     ← Ayarlar
├── core/
│   ├── helpers.php                    ← Yardımcı fonksiyonlar
│   ├── Database.php                   ← Veritabanı sınıfı
│   ├── Session.php                    ← Session yönetimi
│   ├── CSRF.php                       ← CSRF koruması
│   ├── Validator.php                  ← Form doğrulama
│   ├── Router.php                     ← URL yönlendirme
│   ├── Mailer.php                     ← E-posta gönderimi
│   ├── Cache.php                      ← Önbellekleme
│   └── RateLimiter.php                ← Rate limiting
├── controllers/
│   ├── HomeController.php
│   ├── ProductController.php
│   ├── ServiceController.php
│   ├── PageController.php
│   ├── BlogController.php
│   ├── QuoteController.php
│   └── SitemapController.php
├── views/
│   ├── layouts/
│   │   └── main.php                   ← Ana layout
│   ├── partials/
│   │   ├── head.php
│   │   ├── header.php
│   │   ├── footer.php
│   │   ├── breadcrumb.php
│   │   └── quote-modal.php
│   ├── home/
│   │   └── index.php
│   ├── products/
│   │   ├── index.php
│   │   ├── category.php
│   │   └── detail.php
│   ├── services/
│   │   ├── index.php
│   │   └── detail.php
│   ├── pages/
│   │   ├── about.php
│   │   └── contact.php
│   ├── blog/
│   │   ├── index.php
│   │   ├── category.php
│   │   └── detail.php
│   ├── emails/
│   │   └── quote-notification.php
│   └── errors/
│       └── 404.php
├── migrations/
│   └── 001_initial.sql                ← Veritabanı şeması
├── storage/
│   ├── cache/                         ← (777 izni)
│   ├── logs/                          ← (777 izni)
│   └── database.sqlite                ← (otomatik oluşur)
├── public/
│   ├── css/
│   │   ├── critical.css
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   └── images/
│       ├── static/
│       │   ├── placeholder.svg
│       │   └── logo.svg
│       └── uploads/                   ← (777 izni)
└── admin/
    ├── index.php                      ← Admin front controller
    ├── .htaccess
    ├── assets/
    │   ├── admin.css
    │   └── admin.js
    ├── controllers/
    │   ├── AuthController.php
    │   ├── DashboardController.php
    │   ├── CategoryController.php
    │   ├── ProductController.php
    │   ├── ServiceController.php
    │   ├── BlogController.php
    │   ├── SliderController.php
    │   ├── ReviewController.php
    │   ├── PageController.php
    │   ├── QuoteController.php
    │   └── SettingsController.php
    └── views/
        ├── layout.php
        ├── login.php
        ├── change-password.php
        └── dashboard.php