<?php
/**
 * Yardımcı Fonksiyonlar
 */

/**
 * Güvenli çıktı (XSS koruması)
 */
function e(?string $string): string
{
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Site URL'si oluştur
 */
function url(string $path = ''): string
{
    $path = ltrim($path, '/');
    return SITE_URL . '/' . $path;
}

/**
 * Asset URL'si (CSS, JS, resimler)
 */
function asset(string $path): string
{
    $path = ltrim($path, '/');
    
    // SVG placeholder kontrolü
    if (strpos($path, 'placeholder.jpg') !== false) {
        $svgPath = str_replace('placeholder.jpg', 'placeholder.svg', $path);
        if (file_exists(__DIR__ . '/../public/' . $svgPath)) {
            return '/' . $svgPath;
        }
    }
    
    return '/' . $path;
}

/**
 * Yönlendirme
 */
function redirect(string $url, int $code = 302): void
{
    header("Location: {$url}", true, $code);
    exit;
}

/**
 * JSON yanıt
 */
function jsonResponse(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * 404 sayfası göster
 */
function abort404(): void
{
    http_response_code(404);
    require __DIR__ . '/../views/errors/404.php';
    exit;
}

/**
 * Slug oluştur (Türkçe karakter desteği)
 */
function slugify(string $text): string
{
    // Türkçe karakter dönüşümü
    $turkishChars = [
        'ı' => 'i', 'İ' => 'i', 'ğ' => 'g', 'Ğ' => 'g',
        'ü' => 'u', 'Ü' => 'u', 'ş' => 's', 'Ş' => 's',
        'ö' => 'o', 'Ö' => 'o', 'ç' => 'c', 'Ç' => 'c'
    ];
    
    $text = strtr($text, $turkishChars);
    $text = mb_strtolower($text, 'UTF-8');
    $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
    $text = preg_replace('/[\s-]+/', '-', $text);
    $text = trim($text, '-');
    
    return $text;
}

/**
 * Metni kısalt
 */
function truncate(string $text, int $length = 100, string $suffix = '...'): string
{
    $text = strip_tags($text);
    
    if (mb_strlen($text) <= $length) {
        return $text;
    }
    
    return mb_substr($text, 0, $length) . $suffix;
}

/**
 * Tarih formatla (Türkçe)
 */
function formatDate(string $date, string $format = 'd.m.Y'): string
{
    return date($format, strtotime($date));
}

/**
 * Türkçe tarih formatı
 */
function formatDateTurkish(string $date): string
{
    $months = [
        1 => 'Ocak', 2 => 'Şubat', 3 => 'Mart', 4 => 'Nisan',
        5 => 'Mayıs', 6 => 'Haziran', 7 => 'Temmuz', 8 => 'Ağustos',
        9 => 'Eylül', 10 => 'Ekim', 11 => 'Kasım', 12 => 'Aralık'
    ];
    
    $timestamp = strtotime($date);
    $day = date('d', $timestamp);
    $month = $months[(int)date('m', $timestamp)];
    $year = date('Y', $timestamp);
    
    return "{$day} {$month} {$year}";
}

/**
 * Referans numarası oluştur
 */
function generateRefNo(string $prefix = 'TKL'): string
{
    return $prefix . date('ymd') . strtoupper(substr(uniqid(), -5));
}

/**
 * Telefon numarasını formatla
 */
function formatPhone(string $phone): string
{
    $digits = preg_replace('/[^0-9]/', '', $phone);
    
    if (strlen($digits) === 10) {
        return sprintf('(%s) %s %s %s',
            substr($digits, 0, 3),
            substr($digits, 3, 3),
            substr($digits, 6, 2),
            substr($digits, 8, 2)
        );
    }
    
    return $phone;
}

/**
 * WhatsApp linki oluştur
 */
function whatsappLink(string $number, string $message = ''): string
{
    $number = preg_replace('/[^0-9]/', '', $number);
    $url = "https://wa.me/{$number}";
    
    if (!empty($message)) {
        $url .= '?text=' . urlencode($message);
    }
    
    return $url;
}

/**
 * Dosya boyutunu formatla
 */
function formatFileSize(int $bytes): string
{
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    
    return round($bytes, 2) . ' ' . $units[$i];
}

/**
 * Görsel yolu kontrol et, yoksa placeholder döndür
 */
function imageUrl(?string $path, string $placeholder = '/images/static/placeholder.jpg'): string
{
    if (empty($path)) {
        return asset($placeholder);
    }
    
    if (strpos($path, 'http') === 0) {
        return $path;
    }
    
    return asset($path);
}

/**
 * IP adresi al
 */
function getClientIP(): string
{
    $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
    
    foreach ($keys as $key) {
        if (!empty($_SERVER[$key])) {
            $ip = $_SERVER[$key];
            // Birden fazla IP varsa ilkini al
            if (strpos($ip, ',') !== false) {
                $ip = trim(explode(',', $ip)[0]);
            }
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    
    return '0.0.0.0';
}

/**
 * Ayar değeri al
 */
function setting(string $key, $default = null)
{
    static $settings = null;
    
    if ($settings === null) {
        try {
            $rows = Database::fetchAll("SELECT setting_key, setting_value FROM settings");
            $settings = array_column($rows, 'setting_value', 'setting_key');
        } catch (Exception $e) {
            $settings = [];
        }
    }
    
    return $settings[$key] ?? $default;
}

/**
 * View dosyası yükle
 */
function view(string $name, array $data = []): void
{
    extract($data);
    $viewPath = __DIR__ . '/../views/' . str_replace('.', '/', $name) . '.php';
    
    if (!file_exists($viewPath)) {
        throw new Exception("View dosyası bulunamadı: {$name}");
    }
    
    require $viewPath;
}

/**
 * Partial yükle
 */
function partial(string $name, array $data = []): void
{
    view('partials/' . $name, $data);
}

/**
 * Admin view yükle
 */
function adminView(string $name, array $data = []): void
{
    extract($data);
    $viewPath = __DIR__ . '/../admin/views/' . str_replace('.', '/', $name) . '.php';
    
    if (!file_exists($viewPath)) {
        throw new Exception("Admin view dosyası bulunamadı: {$name}");
    }
    
    require $viewPath;
}

/**
 * Debug çıktısı
 */
function dd(...$vars): void
{
    if (!DEBUG_MODE) {
        return;
    }
    
    echo '<pre style="background:#1e1e1e;color:#fff;padding:15px;margin:10px;border-radius:5px;font-size:13px;">';
    foreach ($vars as $var) {
        var_dump($var);
        echo "\n---\n";
    }
    echo '</pre>';
    exit;
}

/**
 * Log yaz
 */
function logError(string $message, array $context = []): void
{
    $logFile = __DIR__ . '/../storage/logs/error.log';
    $logDir = dirname($logFile);
    
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    $timestamp = date('Y-m-d H:i:s');
    $contextStr = !empty($context) ? ' ' . json_encode($context, JSON_UNESCAPED_UNICODE) : '';
    $logLine = "[{$timestamp}] {$message}{$contextStr}\n";
    
    file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
}

/**
 * CSRF input kısayolu
 */
function csrfInput(): string
{
    return CSRF::input();
}

/**
 * Flash mesaj kısayolları
 */
function flashSuccess(string $message): void
{
    Session::flash('success', $message);
}

function flashError(string $message): void
{
    Session::flash('error', $message);
}

function flashWarning(string $message): void
{
    Session::flash('warning', $message);
}